const url_Api = "http://programacion.xyz/mtw/204/crud/index.php/api/"; // referencia del servicio web en CodeIgniter
const url = document.URL;

//properties
var objUsuario = { //objeto que enviaremos al servicio
    id: 0,
    Usua_Nombre : '',
    Usua_Apellidos: ''
};

//LOAD_PAGE
$(document).ready(function(){
    alert("AAA");
    
    objUsuario.id = url.split('?').length> 1 ? url.split('?')[1].split('=')[1] : 0;

    if(objUsuario.id > 0){
        //trae un ID
        LoadPageEditar(objUsuario.id);

        $('#btnGuardar').click(function(){
            alert("guardar");
            GuardarUsuario(objUsuario.id);
    
        });

    }
    else{
        LoadPageUsuarios();


        $('#btnNuevo').click(function(){
            //sólo redirecciona a archivo edicion
            window.location.href = 'edicion.html';
            alert('nuevo');
        });


    }
    
   
});





function LoadUsuariosHTML(result){
    console.log(result);
    if(result.status){
        var tbl = '';

        $.each(result.result, function(i, objUsuario){
            tbl += '<tr>';
            tbl += '<td class="d-none d-md-table-cell">' + (i + 1) + '</td>';
            tbl += '<td class="d-none d-md-table-cell">' + (objUsuario.nombre) + '</td>';
            tbl += '<td class="d-none d-md-table-cell">' + (objUsuario.apellidos) + '</td>';
            tbl += '<td class="d-table-cell d-md-none">' + (objUsuario.nombre + ' ' + objUsuario.apellidos) + '</td>';
            tbl += '<td>';
            tbl += '<div class="d-flex justify-content-center">';
            tbl += '<button class="btn btn-primary" onclick="Editar(' + objUsuario.id + ')" >Editar</button>';
            tbl += '<button class="btn btn-danger ml-2">Eliminar</button>';
            tbl += '</div>';
            tbl += '</td>';
            tbl += '</tr>';
        });

        $('#usuarios-table-body').html(tbl);

    }
    else{
        alert('Error en el servicio. No hay data.status');

    }
}


function LoadPageUsuarios(){
    REST_GetUsuarios();
}

function LoadPageEditar(id){
    REST_GetUsuarioById(id);
}




function Editar(id){
    //redireccionará a la pág de edición
    //editaremos un registro en específico
    window.location.href = "edicion.html?id=" + id;
}

function GuardarUsuario(id)
{
    //alert("estoy en guardar" + id);
        var method = 'post';
        var urlApi = '';

        if(id > 0){
            //alert(id);
            objUsuario.Usua_Nombre = $('#txtNombre').val();
            objUsuario.Usua_Apellidos = $('#txtApellidos').val();

            //alert("obj" + objUsuario.Usua_Nombre);
            method = 'put';
            urlApi = url_Api + 'Usuarios/Actualizar';

            alert(urlApi);
        }
        else{
            urlApi = url_Api + 'Usuarios/Insertar';
        }

        //alert("objid" + objUsuario.id);
        $.ajax({
            type: method,
            url: urlApi,
            data: JSON.stringify(objUsuario), // objeto se convirene a un stringJson
            contentType: 'application/json;charset=utf-8',
            traditional: true,
            success: function(result){
                alert("exito");
                //window.location.href = 'index.html'; // si todo sale bien, redirecciona al inde
            },
            error: function(result){
                
                alert('Error al llamar al servicio' + result);
            }
        });
        
    
}


//LLAMADAS A REST
function REST_GetUsuarios(){

    var url = url_Api + 'Usuarios/Obtener';

    $.ajax({
        type: 'get',
        url: url,
        data: '',
        contentType: 'application/json;charset=utf-8',
        traditional: true,
        success: LoadUsuariosHTML,
        error: function(result){
            alert('Error al llamar al servicio');
        }
    });
    
}


function REST_GetUsuarioById(id){

    var urlApi = url_Api + 'Usuarios/Obtener/';
        //alert("imprime url local?" + url);
        
        //verifica si el ID viene por la URL...si es así, asignamos el valor al ID del obj Usuario
        //usuario.id = url.split('?').length> 1 ? url.split('?')[1].split('=')[1] : 0;
        
        $('#titulo').text('Registrar usuario_');

        if(objUsuario.id > 0){
            //si el ID >0 --> va al servicio para get info, y mostrar en pantalla
            $('#titulo').text('Editar usuario_');

            urlApi += objUsuario.id;
            //alert(urlApi);
            $.ajax({
                type: 'get',
                url: urlApi,
                data: '',
                contentType: 'application/json;charset=utf-8',
                success: function(data){
                    console.log(data);

                    $('#txtNombre').val(data.result[0].nombre);
                    $('#txtApellidos').val(data.result[0].apellidos);
                },
                error: function(result){
                    alert('Error al llamar al servicio');
                }
            });

        }
}


/*
function REST_SetUsuario(){

    var url = url_Api + 'Usuarios/Obtener/';//pendiente por ID para editar

    objUsuario.id = url.split('?').length> 1 ? url.split('?')[1].split('=')[1] : 0;
        
        $('#titulo').text('Registrar usuario_');

        if(objUsuario.id > 0){
            //si el ID >0 --> va al servicio para get info, y mostrar en pantalla
            $('#titulo').text('Editar usuario_');

            urlApi += objUsuario.id;
            //alert(urlApi);
            $.ajax({
                type: 'get',
                url: urlApi,
                data: '',
                contentType: 'application/json;charset=utf-8',
                success: function(data){
                    console.log(data);

                    $('#txtNombre').val(data.result[0].nombre);
                    $('#txtApellidos').val(data.result[0].apellidos);
                },
                error: function(result){
                    alert('Error al llamar al servicio');
                }
            });

        }
    
}
*/