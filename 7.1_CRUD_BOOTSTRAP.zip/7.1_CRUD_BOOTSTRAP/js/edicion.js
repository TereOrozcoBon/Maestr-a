//funcionalidad en JQuery para insertar registrar
//con servicio rest--> 
                    //el CONTROLADOR será el segmento de la URL "usuario"
                    //--> MÉTODO el segmento "insertar"
                    //por http POST

const URL_API = "http://programacion.xyz/mtw/204/crud/index.php/api/"; // referencia del servicio web en CodeIgniter
const url = document.URL;


$(document).ready(function(){
    
   

    var id = 0;
    var parametros = [];

    var usuario = { //objeto que enviaremos al servicio
        id: 0,
        nombre : '',
        apellidos: ''
    };

    
    function CargarPagina()
    {
        
        var urlApi = URL_API + 'Usuarios/Obtener/';
        //alert("imprime url local?" + url);
        
        //verifica si el ID viene por la URL...si es así, asignamos el valor al ID del obj Usuario
        usuario.id = url.split('?').length> 1 ? url.split('?')[1].split('=')[1] : 0;
        
        $('#titulo').text('Registrar usuario_');

        if(usuario.id > 0){
            //si el ID >0 --> va al servicio para get info, y mostrar en pantalla
            $('#titulo').text('Editar usuario_');

            urlApi += usuario.id;
            //alert(urlApi);
            $.ajax({
                type: 'get',
                url: urlApi,
                data: '',
                contentType: 'application/json;charset=utf-8',
                success: function(data){
                    console.log(data);

                    $('#txtNombre').val(data.result[0].nombre);
                    $('#txtApellidos').val(data.result[0].apellidos);
                },
                error: function(result){
                    alert('Error al llamar al servicio');
                }
            });

        }





    }

    $('#btnGuardar').click(function(){
        var method = 'post';
        var urlApi = URL_API + 'Usuarios/Insertar';

        usuario.nombre = $('#txtNombre').val();
        usuario.apellidos = $('#txtApellidos').val();

        if(usuario.id > 0){
            method = 'put';
            urlApi = URL_API + 'Usuarios/Actualizar';
alert(urlApi);
        }

        $.ajax({
            type: method,
            url: urlApi,
            data: JSON.stringify(usuario), // objeto se convirene a un stringJson
            contentType: 'application/json;charset=utf-8',
            traditional: true,
            success: function(result){
                window.location.href = 'index.html'; // si todo sale bien, redirecciona al inde
            },
            error: function(result){
                alert('Error al llamar al servicio');
            }
        });
        
    });

    CargarPagina();


    $('#btnCancelar').click(function(){
        window.location.href = 'index.html';
    });
});