const url_Api = "http://programacion.xyz/mtw/204/crud/index.php/api/"; // referencia del servicio web en CodeIgniter
//const url_Api = "http://localhost:8080/maestria/7.1_CRUD_BOOTSTRAP/"; // referencia del servicio web en CodeIgniter

function Editar(id){
    //redireccionará a la pág de edición
    //editaremos un registro en específico
    window.location.href = "edicion.html?id=" + id;
}


/*
function tblUsuarios(result)
{
    //se enviará la respuesta obtenida del ser web; con la lista de usuarios
    //con la cadena html
    console.log(result);
}
*/



function tblUsuarios(result){
    console.log(result);
    if(result.status){
        var tbl = '';

        $.each(result.result, function(i, usuario){
            tbl += '<tr>';
            tbl += '<td class="d-none d-md-table-cell">' + (i + 1) + '</td>';
            tbl += '<td class="d-none d-md-table-cell">' + (usuario.nombre) + '</td>';
            tbl += '<td class="d-none d-md-table-cell">' + (usuario.apellidos) + '</td>';
            tbl += '<td class="d-table-cell d-md-none">' + (usuario.nombre + ' ' + usuario.apellidos) + '</td>';
            tbl += '<td>';
            tbl += '<div class="d-flex justify-content-center">';
            tbl += '<button class="btn btn-primary" onclick="Editar(' + usuario.id + ')" >Editar</button>';
            tbl += '<button class="btn btn-danger ml-2">Eliminar</button>';
            tbl += '</div>';
            tbl += '</td>';
            tbl += '</tr>';
        });

        $('#usuarios-table-body').html(tbl);

    }
    else{
        alert('Error en el servicio. No hay data.status');

    }
}





$(document).ready(function(){
//$(document).ready(() => {
    //arranca cuando el documento esté listo; los recursos ya estén cargados
    

    //jquery 
    //acceder al boton a traves de ID
    //eventos click para BUSCAR y NUEVO
    function CargarPageIndex(){

        GetUsuarios();

    }


    $('#btnBuscar').click(function(){
        //llamada al serv REST para get lista de usuarios
        GetUsuarios();
    });

    CargarPageIndex();

    function GetUsuarios(){


        var url = url_Api + 'Usuarios/Obtener';

        //alert("la url es: "+ url_Api);
        //alert("2da alert");
        
        $.ajax({
            type: 'get',
            url: url,
            data: '',
            contentType: 'application/json;charset=utf-8',
            traditional: true,
            success: tblUsuarios,
            error: function(result){
                alert('Error al llamar al servicio');
            }
        });
        
    }

//explicación
/*
    type: 'get',
            url: url, //direccipon del controlador USUARIOS y metodo para obtener registros de usuarios (obtener)
            data: '',
            contentType: 'application/json;charset=utf-8',
            traditional: true,
            success: tblUsuarios, //si es exitoso, result sea enviado a una función tblUsuarios
            error: function(result){ // error función anónima para mandar el msj al usuario
                alert('Error al llamar al servicio');
            }
*/



    $('#btnNuevo').click(function(){
        //sólo redirecciona a archivo edicion
        window.location.href = 'edicion.html';
        alert('nuevo');
    });



});
