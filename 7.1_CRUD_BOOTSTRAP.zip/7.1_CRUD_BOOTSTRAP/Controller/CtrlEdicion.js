const url_Api = "http://programacion.xyz/mtw/204/crud/index.php/api/"; // referencia del servicio web en CodeIgniter
const url = document.URL;


//LOAD_PAGE
$(document).ready(function(){
    //properties
    var objUsuario = { //objeto que enviaremos al servicio
        id: 0,
        nombre : '',
        apellidos: ''
    };



    function CargarPageEdicion()
    {

        objUsuario.id = url.split('?').length> 1 ? url.split('?')[1].split('=')[1] : 0;

        
        var urlApi = url_Api + 'Usuarios/Obtener/';
        
        //verifica si el ID viene por la URL...si es así, asignamos el valor al ID del obj Usuario

        $('#titulo').text('Registrar usuario_');

        
        if(objUsuario.id > 0){
            //si el ID >0 --> va al servicio para get info, y mostrar en pantalla
            $('#titulo').text('Editar usuario_');

            urlApi += objUsuario.id;
            
            $.ajax({
                type: 'get',
                url: urlApi,
                data: '',
                contentType: 'application/json;charset=utf-8',
                success: function(data){
                    console.log(data);

                    $('#txtNombre').val(data.result[0].nombre);
                    $('#txtApellidos').val(data.result[0].apellidos);
                },
                error: function(result){
                    alert('Error al llamar al servicio');
                }
            });

        }
    }

    $('#btnGuardar').click(()=>{
        
        //GuardarUsuario(objUsuario.id);
        var method = 'post';
        var urlApi = url_Api + 'usuarios/insertar';

        //objUsuario.id = 0;
        objUsuario.nombre = $('#txtNombre').val();
        objUsuario.apellidos = $('#txtApellidos').val();

        
        
        if(objUsuario.id > 0){
            
            method = 'put';
            urlApi = url_Api + 'usuarios/actualizar';
        }

        //alert("metodo: " + method +  "; url: " + urlApi + "; id: " + objUsuario.id);
        
        $.ajax({
            type: method,
            url: urlApi,
            data: JSON.stringify(objUsuario), 
            contentType: 'application/json;charset=utf-8',
            success: function(result){
                
                window.location.href = 'ListadoUsuarios.html'; 
            },
            error: function(result){
                
                alert('Error al llamar al servicio: ' + result.id);
            }
        });

    });


    CargarPageEdicion();


    /*
    objUsuario.id = url.split('?').length> 1 ? url.split('?')[1].split('=')[1] : 0;
    
    if(objUsuario.id == 0){
        //Add Usuario

    }
    else
    {
        CargarPageEdicion(objUsuario);
    
    }

    */
    

    

/*
    if(objUsuario.id > 0){
        //trae un IDalert("hay");



        LoadPageEditar(objUsuario.id);
    }
    else{
        //Nuevo registro:
        urlApi += usuario.id;
            $.ajax({
                type: 'get',
                url: urlApi,
                data: '',
                contentType: 'application/json;charset=utf-8',
                success: function(data){
                    console.log(data);

                    $('#txtNombre').val(data.result[0].nombre);
                    $('#txtApellidos').val(data.result[0].apellidos);
                },
                error: function(result){
                    alert('Error al llamar al servicio');
                }
            });
    }
   */

});


function LoadPageEditar(id){
    REST_GetUsuarioById(id);
}


function GuardarUsuario(id)
{
        var method = 'post';
        var urlApi = '';

        //objUsuario.id = 0;
        objUsuario.nombre = $('#txtNombre').val();
        objUsuario.apellidos = $('#txtApellidos').val();

        if(id > 0){
            
            //alert("obj" + objUsuario.Usua_Nombre);
            method = 'put';
            urlApi = url_Api + 'Usuarios/Actualizar';

            objUsuario.id = id;
        }
        else{
            
            urlApi = url_Api + 'Usuarios/Insertar';
        }

        
        $.ajax({
            type: method,
            url: urlApi,
            data: JSON.stringify(objUsuario), // objeto se convirene a un stringJson
            contentType: 'application/json;charset=utf-8',
            traditional: true,
            success: function(result){
                
                window.location.href = 'ListadoUsuarios.html'; // si todo sale bien, redirecciona al inde
            },
            error: function(result){
                
                alert('Error al llamar al servicio' + result);
            }
        });
        
    //redireccionar a Listado
}
