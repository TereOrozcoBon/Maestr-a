const url_Api = "http://programacion.xyz/mtw/204/crud/index.php/api/"; // referencia del servicio web en CodeIgniter
const url = document.URL;

//properties
var objUsuario = { //objeto que enviaremos al servicio
    id: 0,
    nombre : '',
    apellidos: ''
};


//LOAD_PAGE
$(document).ready(function(){

    REST_GetUsuarios();

    $('#btnNuevo').click(function(){
        //sólo redirecciona a archivo edicion
        window.location.href = 'Edicion.html';
        alert('nuevo');
    });
});

function LoadUsuariosHTML(result){
    
    if(result.status){
        //alert("result estatus: "+ result.status);

        var tbl = '';

        $.each(result.result, function(i, objUsuario){
            tbl += '<tr>';
            tbl += '<td class="d-none d-md-table-cell">' + (i + 1) + '</td>';
            tbl += '<td class="d-none d-md-table-cell">' + (objUsuario.nombre) + '</td>';
            tbl += '<td class="d-none d-md-table-cell">' + (objUsuario.apellidos) + '</td>';
            tbl += '<td class="d-table-cell d-md-none">' + (objUsuario.nombre + ' ' + objUsuario.apellidos) + '</td>';
            tbl += '<td>';
            tbl += '<div class="d-flex justify-content-center">';
            tbl += '<button class="btn btn-primary" onclick="Editar(' + objUsuario.id + ')" >Editar</button>';
            tbl += '<button class="btn btn-danger ml-2" onclick="Eliminar(' + objUsuario.id + ')" >Eliminar</button>';
            tbl += '</div>';
            tbl += '</td>';
            tbl += '</tr>';
        });

        $('#usuarios-table-body').html(tbl);

    }
    else{
        alert('Error en el servicio. No hay data.status');

    }
}

//LLAMADAS A REST
function REST_GetUsuarios(){

    var url = url_Api + 'Usuarios/Obtener';


    $.ajax({
        type: 'get',
        url: url,
        data: '',
        contentType: 'application/json;charset=utf-8',
        traditional: true,
        success: LoadUsuariosHTML,
        error: function(result){
            alert('Error al llamar al servicio');
        }
    });
    
}


function Editar(id){
    //redireccionará a la pág de edición
    //editaremos un registro en específico
    window.location.href = "Edicion.html?id=" + id;
}


function Eliminar(id){
    var url = url_Api + 'Usuarios/Eliminar/' + id;

    console.log(url);

    $.ajax({
        type: 'delete',
        url: url,
        data: JSON.stringify(objUsuario), 
        contentType: 'application/json;charset=utf-8',
        success: function(){
            alert("registro eliminado");
            REST_GetUsuarios();  
        },
        error: function(result){
            alert('Error al llamar al servicio');
        }
    });



}