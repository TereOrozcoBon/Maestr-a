<?php
    defined('BASEPATH') OR EXIT('NO XXX');
    require APPPATH . '/libraries/REST_Controller.php'; //Hacer referencia para poder heredar de

    class CtrlUsuarios extends REST_Controller{
        // clase Usuarios hereda de REST_Controller

        //constructor para incluír las librerías de DATABASE u URL
        public function __construct(){
            parent ::__construct();

            $this->load->database();
            $this->load->helper('url');
        }




        //MÉTODO GET (solito, que funciona, pero este método puede servirnos para GET todos los registros o filtrar por ID)
        /*
        public function obtener_get() {
            //para los RESULT se usa el método SET_RESPONSE (de rest_controller)
            //--> rest_controller(<estructura que retornaremos>, <código de estatus del HTTP que queremos retornar>)

            //Obtener los registros de USUARIOS en array asociativo
            $usuarios = []; // vacía o no, retornará un array asociativo con STATUS|MESSAGE|RESULT
            $usuarios = $this->db->get('usuarios')->result_array();

            if(!empty($usuarios)){
                $this->set_response(
                    [
                        'status' => TRUE,
                        'message' => '',
                        'result' => $usuarios
                    ],
                    REST_Controller::HTTP_OK    // (200)
                );
            }
            else{
                $this->set_response(
                    [
                        'status' => FALSE,
                        'message' => 'Usuarios no encontrados',
                        'result' => []
                    ],
                    REST_Controller::HTTP_NOT_FOUND    // (400)
                );

            }
            */

            
            public function obtener_get($id = 0) {
            //Obtener los registros de USUARIOS en array asociativo
            $usuarios = []; // vacía o no, retornará un array asociativo con STATUS|MESSAGE|RESULT
            
            //validar si existe el ID en la DB
            if($id > 0){
                //update
                $this->db->where('Usua_Id', $id);
            }
            //else {
                //haría un insert
            //}

            $usuarios = $this->db->get('usuarios')->result_array();

            if(!empty($usuarios)){
                $this->set_response(
                    [
                        'status' => TRUE,
                        'message' => '',
                        'result' => $usuarios
                    ],
                    REST_Controller::HTTP_OK    // (200)
                );
            }
            else{
                $this->set_response(
                    [
                        'status' => FALSE,
                        'message' => 'Usuarios no encontrados',
                        'result' => []
                    ],
                    REST_Controller::HTTP_NOT_FOUND    // (400)
                );

            }

        }


        //DELETE
        public function eliminar_delete($id){
            //eliminará sólo el ID que le especificaremos
            $this->db->where('Usua_Id', $id);

            //EXEC
            $this->db->delete('usuarios');

            $this->set_response(
                [
                    'id' => $id,
                    'message' => 'Registro eliminado correctamente',
                    'result' => []
                ],
                REST_Controller::HTTP_NO_CONTENT
            );
            //**********************************************************************no me arroja respuesta al eliminar */
        }



        //INSERT
        public function insertar_post(){
            //get la info que viene en el cuerpo del msg
            $data = file_get_contents("php://input");

            //Decodificamos el formato JSon
            $usuario = json_decode($data);

            //insertarmos los registros
            $this->db->insert('usuarios', $usuario);

            //obtenemos el último ID registrado en la cnx actual
            $usuario->id = $this->db->insert_id();

            //retornamos el registro insertado jusnto con su nuevo ID
            $this->set_response(
                $usuario,
                REST_Controller::HTTP_CREATED
            );
        }

        public function actualizar_put(){
            //get la info del cuerpo del msj
            $data = file_get_contents("php://input");

            //decodificamos a  formato JSon
            $usuario = json_decode($data);

            //especificamos que el update será sobre el ID 
            $this->db->where('Usua_Id', $usuario->id);

            //actualizamos la info en la tabla
            $this->db->update('usuarios', $usuario);


            //********************************************************no me manda respuesta, sólo lo actualiza */
            $this->set_response(
                [
                    'id' => $usuario->id,
                    'message' => 'Registro actualizado correctamente',
                    'result' => []
                ],
                REST_Controller::HTTP_NO_CONTENT
                );
        }
    }
?>